<?php
/**
Plugin Name: Smart Transfer
Plugin URI: https://smartinfosys.net
Version: 1.0
Author: Smart Infosys
Description: Transfer Large Files using WeTransfer Embed API.
Text Domain: wetransfer
*/
// If this file is called directly, abort.
if(!defined('WPINC')){
	die;
}

//Get Form shortcode to display upload form

function wetransfer_getForm(){
	
	?>
	
	
	<form method="post" action="#">
	<?php wp_nonce_field('update-options') ?>
	<p>Your Name:<br/><input type='text' name='your_name' placeholder='Your Name'></p>
	<p>Your Email:<br/><input type='email' name='your_email' placeholder='Your Email' required></p>
	<p>File Name:<br/><input type='text' name='your_file' placeholder='Your File Name'></p>
	
	
	
	<div data-widget-host="habitat" id="wt_embed">
  <script type="text/props">
    {
      "wtEmbedKey": "e6dc2fef-cc3d-4816-8265-e058d1c996a1",
      "wtEmbedOutput": ".wt_embed_output",
      "wtEmbedLanguage": "en"
    }
  </script>
</div>
<script async src="https://prod-embed-cdn.wetransfer.net/v1/latest.js"></script>
<!--
  The next input element will hold the transfer link. For testing purposes, you
  could change the type attribute to "text", instead of "hidden".
-->
<input type="hidden" name="wt_embed_output" class="wt_embed_output" />
	
	
	<p><br/><input type='submit' name='submit_file' value='submit'></p>
	</form>
	<?php
}
	
add_shortcode('smartTransfer','wetransfer_getForm');

//save form data to database

if(isset($_POST['submit_file'])){	
global $wpdb;
$dataArray = array(
	
	'yname' => $_POST['your_name'],
	'yemail' => $_POST['your_email'],
	'yfile' => $_POST['your_file'],
	'yurl' => $_POST['wt_embed_output']
	
);
$table = 'wetransfer';
$insert = $wpdb->insert($table, $dataArray);
if($insert){
	echo "Saved";
}
}
//Add admin menu and create page

function wetransfer_settings_page(){
	add_menu_page(
	'Smart Transfer',
	'Smart Transfer',
	'manage_options',
	'wetransfer',
	'wetransfer_setting_page_markup',
	'dashicons-paperclip',
	100
	);
}
add_action('admin_menu','wetransfer_settings_page');

function wetransfer_setting_page_markup(){
	
	global $wpdb;
	$table = 'wetransfer';
	$results = $wpdb->get_results("select * from $table");
	
echo "<h2>Your Data</h2>";
echo "<table><tr><th>Name</th><th>Email</th><th>File</th><th>Url</th></tr>";

foreach($results as $result){

echo "<tr><td>$result->yname</td><td>$result->yemail</td><td>$result->yfile</td><td><a href='$result->yurl' target='_blank'>$result->yurl</a></td></tr>";
}
echo "</table>";

}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	