<?php
/*
Plugin Name: Smart WeTransfer
Plugin URI: https://grittechnologies.com
Version: 1.0
Author: Mrityunjay Kumar
Author URI: https://facebook.com/mrityunjaykumarmishra
Description: Transfer Large Files using WeTransfer Embed API.
Text Domain: wetransfer
Domain Path: /languages
*/
// If this file is called directly, abort.
if(!defined('WPINC')){
	die;
}
define('WETRANSFER_PLUGIN_PATH',plugin_dir_url(__FILE__)); //plugin directory path
include(plugin_dir_path(__FILE__).'includes/style.php');
//Get Form shortcode to display upload form

function wetransfer_getForm(){
	?>
	
	
	<form method="post" action="#">
	<?php wp_nonce_field('update-options') ?>
	<p>Your Name:<br/><input type='text' name='your_name' placeholder='Your Name'></p>
	<p>Your Email:<br/><input type='email' name='your_email' placeholder='Your Email' required></p>
	<p>File Name:<br/><input type='text' name='your_file' placeholder='Your File Name'></p>
	
	
	
	<div data-widget-host="habitat" id="wt_embed">
	
  <script type="text/props">
    {
      "wtEmbedKey": "<?php echo get_option('wetransfer_key'); ?>",
      "wtEmbedOutput": ".wt_embed_output",
      "wtEmbedLanguage": "en"
    }
  </script>
</div>
<script async src="https://prod-embed-cdn.wetransfer.net/v1/latest.js"></script>
<!--
  The next input element will hold the transfer link. For testing purposes, you
  could change the type attribute to "text", instead of "hidden".
-->
<input type="hidden" name="wt_embed_output" class="wt_embed_output" />
	
	
	<p><br/><input type='submit' name='submit_file' value='submit'></p>
	</form><?php
}
	
add_shortcode('smartTransfer','wetransfer_getForm');

//save form data to database

if(isset($_POST['submit_file'])){	
global $wpdb;
$dataArray = array(
	
	'yname' => $_POST['your_name'],
	'yemail' => $_POST['your_email'],
	'yfile' => $_POST['your_file'],
	'yurl' => $_POST['wt_embed_output']
	
);
$table =  $wpdb->prefix . 'wetransfer';
$insert = $wpdb->insert($table, $dataArray);
if($insert){
	echo "Saved";
}
}
//create plugin table
global $jal_db_version;
$jal_db_version = '1.0';

function jal_install() {
	global $wpdb;
	global $jal_db_version;

	$table_name = $wpdb->prefix . 'wetransfer';
	
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		time datetime DEFAULT current_timestamp NOT NULL,
		yname text NOT NULL,
		yemail text NOT NULL,
		yfile text NOT NULL,
		yurl varchar(55) DEFAULT '' NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );

	add_option( 'jal_db_version', $jal_db_version );
}
register_activation_hook( __FILE__, 'jal_install' );
//Add admin menu and create page

function wetransfer_settings_page(){
	add_menu_page(
	__('Smart WeTransfer','wetransfer'),  //page name
	__('Smart WeTransfer','wetransfer'),  // menu name
	'manage_options', //To show menu in dashboard menu
	'wetransfer',  //slug
	'wetransfer_setting_page_markup',  // callback function
	'dashicons-paperclip',  //Icon
	100  //Position
	);
	add_submenu_page(
		'wetransfer', //Parent Slug
		__('settings','wetransfer'), //Page name 
		__('Settings','wetransfer'), //Menu name
		  'manage_options',
		  'wetransfer_settings', // slug
		   'wetransfer_subpage_markup' //callback function
	);
}
add_action('admin_menu','wetransfer_settings_page');

function wetransfer_setting_page_markup(){

	if ( !current_user_can('manage_options') ) {
		return;
	}
	
	global $wpdb;
	$table =  $wpdb->prefix . 'wetransfer';
	$results = $wpdb->get_results("select * from $table");
echo "<div class='wrap'>";	
echo "<h2>Your Data</h2><p>Your uploads will be automatically deleted from wetransfer free plan!</p>";
echo "<table class='table'><tr><th>Name</th><th>Email</th><th>File</th><th>Url</th><th>Upload Date</th></tr>";

foreach($results as $result){
$date=date_create($result->time);
$date = date_format($date,"Y/m/d H:i:s");
echo "<tr><td>$result->yname</td><td>$result->yemail</td><td>$result->yfile</td><td><a href='$result->yurl' target='_blank'>$result->yurl</a></td><td>$date</td></tr>";
}
echo "</table></div>";

}
function wetransfer_subpage_markup(){
	
	?>
	<div class='wrap'>
	<form method="post" action="options.php">
	<?php wp_nonce_field('update-options') ?>
	<p><strong>Add Wetransfer API Key here</strong><br />
	<input type="text" class='form-control' name="wetransfer_key" size="45" value="<?php echo get_option('wetransfer_key'); ?>" /></p>
	<p><input type="submit" class='btn btn-primary' name="Submit" value="Update Key" /></p>

	<input type="hidden" name="action" value="update" />
	<input type="hidden" name="page_options" value="wetransfer_key" />
	</form>
	
	</div>
<h3>How To Use</h3><p>Use Shortcode <pre><strong>[smartTransfer]</strong></pre> in your Post or Page or <pre><strong> &lt;?php echo do_shortcode('[smartTransfer]');?&gt;</strong> </pre> in your template. Get WeTransfer API key from <a target='_blank' href="https://wetransfer.com/">https://wetransfer.com/</a>
where you can send 2GB data for free and it will be saved for 7 days in free account.</p>
<?php
}
//Add link to setting page after plugin gets activated

function wetransfer_add_setting_link($links){
	$settings_link = '<a href="admin.php?page=wetransfer_settings">'.__('Settings','wetransfer'). '</a>';
	array_push($links,$settings_link);
	return $links;
}
$filter_name = "plugin_action_links_".plugin_basename(__FILE__);
add_filter($filter_name,'wetransfer_add_setting_link');
?>